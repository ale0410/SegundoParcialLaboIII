/// <reference path="./Auto.ts"/>
/// <reference path="./Camioneta.ts"/>
/// <reference path="./Vehiculo.ts"/>
var general;
(function (general) {
    window.addEventListener("load", function () {
        document.getElementById("btnAlta").addEventListener("click", general.guardarVehiculo);
    });
    var listaVehiculos = new Array();
    function CalcularID() {
        return listaVehiculos.length + 1;
    }
    function guardarVehiculo() {
        var id = CalcularID();
        var elementoMarca = document.getElementById("marca");
        var elementoModelo = document.getElementById("modelo");
        var elementoPrecio = document.getElementById("precio");
        var elementoTipo = document.getElementById("tipo");
        var marca = elementoMarca.value;
        var modelo = elementoModelo.value;
        var precio = parseInt(elementoPrecio.value);
        var tipo = elementoTipo.value;
        if (tipo === "Auto") {
            var miVehiculo = new general.Auto(id, marca, modelo, precio, 4);
        }
        listaVehiculos.push(miVehiculo);
        mostrarVehiculo(id, marca, modelo, precio);
    }
    general.guardarVehiculo = guardarVehiculo;
    function mostrarVehiculo(id, marca, modelo, precio) {
        var cuerpo = document.getElementById("cuerpo");
        cuerpo.hidden = false;
        cuerpo.innerHTML = cuerpo.innerHTML + "<tr><td>" + id + "</td><td>" + marca + "</td><td>" + modelo + "</td><td>" + precio + "</td><td><a href='' onclick='borrar(event)'>borrar</a></td></tr>";
    }
    general.mostrarVehiculo = mostrarVehiculo;
    function borrar(e) {
        e.preventDefault();
        //console.log(e);
        //console.log(e.target);
        var tagA = e.target;
        var tr = tagA.parentNode.parentNode;
        console.log(tr);
        tr.innerHTML = "";
        //var body = tr.parentNode;
        //var tabla = body.parentNode;
        //BoShowMessage(body.id);
        //tabla.RemoveChildren(tr);
    }
    function CerrarVehiculo() {
        var contenedorVehiculo = document.getElementById("agregarVehiculo");
        contenedorVehiculo.hidden = true;
    }
    general.CerrarVehiculo = CerrarVehiculo;
})(general || (general = {}));
