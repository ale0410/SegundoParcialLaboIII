/// <reference path="./Vehiculo.ts"/>

namespace general{
    export class Auto extends Vehiculo
    {
        private cantidadPuertas:number;

        constructor(id:number, marca:string, modelo:string, precio:number,cantidadPuertas:number) 
        {
            super(id,marca,modelo,precio);
            this.cantidadPuertas = cantidadPuertas;
        }

        public getCantidadPuertas():number
        {
            return this.cantidadPuertas;
        }

        toJson():string{
            var jsonPadre:string = super.toJson();
            return jsonPadre + " - cantidad de puertas: "+ this.getCantidadPuertas() + "}";
        }
    }
}