/// <reference path="./Auto.ts"/>
/// <reference path="./Camioneta.ts"/>
/// <reference path="./Vehiculo.ts"/>

namespace general{

    window.addEventListener("load", function(){
       document.getElementById("btnAlta").addEventListener("click",general.guardarVehiculo);
       
    });

    var listaVehiculos:Array<Vehiculo> = new Array<Vehiculo>();

    function CalcularID():number{
         return listaVehiculos.length+1;
    }
    
    export function guardarVehiculo()
    {   
        var id = CalcularID();
        var elementoMarca = <HTMLInputElement>document.getElementById("marca");
        var elementoModelo = <HTMLInputElement>document.getElementById("modelo");
        var elementoPrecio = <HTMLInputElement>document.getElementById("precio");
        var elementoTipo = <HTMLInputElement>document.getElementById("tipo");
        var marca:string = elementoMarca.value;
        var modelo:string = elementoModelo.value;
        var precio:number = parseInt(elementoPrecio.value);
        var tipo:string = elementoTipo.value;

        if(tipo === "Auto")
        {
            var miVehiculo:Auto = new Auto(id,marca,modelo,precio,4);
        }

         listaVehiculos.push(miVehiculo);

         mostrarVehiculo(id, marca, modelo, precio);
         
    }


    export function mostrarVehiculo(id, marca, modelo, precio)
    {
        var cuerpo = document.getElementById("cuerpo");
        cuerpo.hidden = false;
        cuerpo.innerHTML = cuerpo.innerHTML + "<tr><td>" + id + "</td><td>" + marca + "</td><td>" + modelo + "</td><td>" + precio + "</td><td><a href='' onclick='borrar(event)'>borrar</a></td></tr>";
    }

    function borrar(e)
    {
        e.preventDefault();
        //console.log(e);
        //console.log(e.target);
        var tagA = e.target;
        var tr = tagA.parentNode.parentNode;
        console.log(tr);
        tr.innerHTML = "";
        //var body = tr.parentNode;
        //var tabla = body.parentNode;
        //BoShowMessage(body.id);
        //tabla.RemoveChildren(tr);
    }


    export function CerrarVehiculo()
    {
       var contenedorVehiculo = <HTMLInputElement>document.getElementById("agregarVehiculo");
       contenedorVehiculo.hidden = true;
    }

}