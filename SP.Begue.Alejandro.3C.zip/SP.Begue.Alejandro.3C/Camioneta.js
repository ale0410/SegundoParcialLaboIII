/// <reference path="./Vehiculo.ts"/>
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var general;
(function (general) {
    var Camioneta = /** @class */ (function (_super) {
        __extends(Camioneta, _super);
        function Camioneta(id, marca, modelo, precio, cuatroXCuatro) {
            var _this = _super.call(this, id, marca, modelo, precio) || this;
            _this.cuatroXCuatro = cuatroXCuatro;
            return _this;
        }
        Camioneta.prototype.getCuatroXCuatro = function () {
            return this.cuatroXCuatro;
        };
        Camioneta.prototype.toJson = function () {
            var jsonPadre = _super.prototype.toJson.call(this);
            return jsonPadre + " - cuatro por cuatro: " + this.getCuatroXCuatro() + "}";
        };
        return Camioneta;
    }(general.Vehiculo));
    general.Camioneta = Camioneta;
})(general || (general = {}));
