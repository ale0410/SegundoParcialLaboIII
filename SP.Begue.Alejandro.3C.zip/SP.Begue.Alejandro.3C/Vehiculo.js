var general;
(function (general) {
    var Vehiculo = /** @class */ (function () {
        function Vehiculo(id, marca, modelo, precio) {
            this.marca = marca;
            this.modelo = modelo;
            this.precio = precio;
        }
        Vehiculo.prototype.getMarca = function () {
            return this.marca;
        };
        Vehiculo.prototype.getModelo = function () {
            return this.modelo;
        };
        Vehiculo.prototype.getPrecio = function () {
            return this.precio;
        };
        Vehiculo.prototype.toJson = function () {
            return "{marca: " + this.getMarca() + " - modelo: " + this.getModelo() + " - precio: " + this.getPrecio() + "}";
        };
        return Vehiculo;
    }());
    general.Vehiculo = Vehiculo;
})(general || (general = {}));
