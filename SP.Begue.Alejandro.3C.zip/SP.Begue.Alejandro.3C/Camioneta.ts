/// <reference path="./Vehiculo.ts"/>

namespace general{
    export class Camioneta extends Vehiculo
    {
        private cuatroXCuatro:number;

        constructor(id:number,marca:string, modelo:string, precio:number,cuatroXCuatro:number) 
        {
            super(id,marca,modelo,precio);
            this.cuatroXCuatro = cuatroXCuatro;
        }

        public getCuatroXCuatro():number
        {
            return this.cuatroXCuatro
        }

        toJson():string{
            var jsonPadre:string = super.toJson();
            return jsonPadre + " - cuatro por cuatro: "+ this.getCuatroXCuatro() + "}";
        }
    }
}