namespace general{
    export class Vehiculo
    {
        private id:number;
        public marca:string;
        public modelo:string;
        public precio:number;

        constructor(id:number, marca:string, modelo:string, precio:number)
        {
            this.marca = marca;
            this.modelo = modelo;
            this.precio = precio;
        }

        public getMarca():string{
            return this.marca;
        }

        public getModelo():string{
            return this.modelo;
        }

        public getPrecio():number{
            return this.precio;
        }

        toJson():string{
            return "{marca: "+ this.getMarca() + " - modelo: " + this.getModelo() + " - precio: " + this.getPrecio() + "}";
        }
    }
}